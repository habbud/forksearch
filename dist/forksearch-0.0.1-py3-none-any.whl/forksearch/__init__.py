"""
Object initialization for CLI
"""
from rich.console import Console

console = Console()
